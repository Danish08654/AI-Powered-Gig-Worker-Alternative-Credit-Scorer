import json
import uuid
import joblib
import shap
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from schema import ApplicantInput, CreditDecision

app = FastAPI(
    title="Gig Worker Credit Scorer API",
    description="Alternative credit scoring using gig economy signals",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

# LOAD MODEL SAFELY
model = joblib.load("credit_model.joblib")

with open("model_metadata.json") as f:
    metadata = json.load(f)

FEATURES = metadata["features"]
THRESHOLD = metadata["threshold"]

explainer = shap.TreeExplainer(model)


# FEATURE ENGINEERING
def engineer_features(data: dict) -> pd.DataFrame:
    df = pd.DataFrame([data])

    df['income_stability_score'] = df['monthly_income_mean'] / (df['monthly_income_std'] + 1)
    df['platform_diversification'] = df['active_platforms'] / df['platform_tenure_months'].clip(lower=1)
    df['financial_cushion'] = df['savings_buffer_months'] * (1 - df['expense_ratio'])
    df['risk_composite'] = (
        df['debt_to_income'] * df['expense_ratio'] / (df['on_time_payment_rate'] + 0.01)
    )

    return df[FEATURES]

# UTILS
def probability_to_score(prob: float) -> int:
    return int(850 - (prob * 550))


def get_risk_tier(prob: float) -> str:
    if prob < 0.15:
        return "Excellent"
    elif prob < 0.30:
        return "Good"
    elif prob < 0.50:
        return "Fair"
    elif prob < 0.70:
        return "Poor"
    else:
        return "Very High Risk"


# ROOT
@app.get("/")
def root():
    return {
        "service": "Gig Worker Credit Scorer",
        "version": metadata["version"],
        "model_auc": metadata["model_auc"],
        "status": "healthy"
    }

# SCORE ENDPOINT (FIXED)
@app.post("/score")
def score_applicant(applicant: ApplicantInput):

    try:
        #  INPUT 
        input_dict = applicant.model_dump()
        X = engineer_features(input_dict)

        #  PREDICTION 
        default_prob = float(model.predict_proba(X)[0][1])
        credit_score = probability_to_score(default_prob)
        decision = "APPROVED" if default_prob < THRESHOLD else "DECLINED"
        risk_tier = get_risk_tier(default_prob)

        #  SHAP SAFE FIX 
        shap_values = explainer.shap_values(X)

        if isinstance(shap_values, list):
            shap_vals = shap_values[1][0]
        else:
            shap_vals = shap_values[0]

        shap_pairs = list(zip(FEATURES, shap_vals))

        sorted_shap = sorted(shap_pairs, key=lambda x: abs(x[1]), reverse=True)

        risk_factors = [
            {"feature": f, "impact": round(v, 4)}
            for f, v in sorted_shap if v > 0
        ][:3]

        protective_factors = [
            {"feature": f, "impact": round(abs(v), 4)}
            for f, v in sorted_shap if v < 0
        ][:3]

        #  GUARANTEED RESPONSE 
        return {
            "applicant_id": str(uuid.uuid4()),
            "default_probability": round(default_prob, 4),
            "credit_score": credit_score,
            "decision": decision,
            "risk_tier": risk_tier,
            "top_risk_factors": risk_factors,
            "top_protective_factors": protective_factors
        }

    except Exception as e:
        # IMPORTANT: NEVER BREAK STREAMLIT
        return {
            "error": str(e),
            "decision": "ERROR"
        }


# MODEL INFO
@app.get("/model/info")
def model_info():
    return metadata