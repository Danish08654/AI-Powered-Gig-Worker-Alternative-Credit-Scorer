from pydantic import BaseModel, Field

class ApplicantInput(BaseModel):
    platform_tenure_months: int = Field(..., ge=1, le=120, description="Months active on gig platforms")
    monthly_income_mean: float = Field(..., ge=0, description="Average monthly income ($)")
    monthly_income_std: float = Field(..., ge=0, description="Monthly income volatility ($)")
    income_trend: float = Field(..., ge=-1, le=1, description="Income trend (-1 declining, +1 growing)")
    active_platforms: int = Field(..., ge=1, le=10, description="Number of active gig platforms")
    on_time_payment_rate: float = Field(..., ge=0, le=1, description="On-time bill payment rate")
    expense_ratio: float = Field(..., ge=0, le=1, description="Monthly expenses / income ratio")
    debt_to_income: float = Field(..., ge=0, le=1, description="Debt-to-income ratio")
    savings_buffer_months: float = Field(..., ge=0, description="Months of expenses saved")
    total_gig_history_months: int = Field(..., ge=1, description="Total gig work history in months")

class CreditDecision(BaseModel):
    applicant_id: str
    default_probability: float
    credit_score: int
    decision: str
    risk_tier: str
    top_risk_factors: list
    top_protective_factors: list